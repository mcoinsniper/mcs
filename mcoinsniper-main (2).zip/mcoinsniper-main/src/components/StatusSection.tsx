import { motion } from "framer-motion";

const statuses = [
  {
    number: "01",
    title: "SKIP",
    badge: "DANGER",
    description: "Risk is too high. Rug probability detected. Capital protection becomes the priority.",
    borderColor: "border-signal-skip",
    textColor: "text-signal-skip",
    bgColor: "bg-signal-skip",
  },
  {
    number: "02",
    title: "RISKY",
    badge: "WAIT",
    description: "Missing or unclear data. Observation required. Waiting is often safer than acting.",
    borderColor: "border-signal-risky",
    textColor: "text-signal-risky",
    bgColor: "bg-signal-risky",
  },
  {
    number: "03",
    title: "WATCH",
    badge: "RADAR",
    description: "Valid structure. Waiting for confirmation signal. Setups developing live.",
    borderColor: "border-signal-watch",
    textColor: "text-signal-watch",
    bgColor: "bg-signal-watch",
  },
  {
    number: "04",
    title: "PRIME",
    badge: "CLEARED",
    description: "All critical indicators aligned. Survival check passed. High-confidence conditions met.",
    borderColor: "border-signal-prime",
    textColor: "text-signal-prime",
    bgColor: "bg-signal-prime",
    featured: true,
  },
];

const StatusSection = () => {
  return (
    <section id="status" className="py-24 bg-background border-t border-border">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-6"
        >
          <h2 className="section-title mb-4">
            /// Classification Protocol
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Based on all collected data, I assign clear statuses. <strong className="text-foreground">Green is rare</strong> and appears only when all critical indicators are aligned. Survival is always more important than profit.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
          {statuses.map((status, index) => (
            <motion.div
              key={status.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className={`glass-card p-6 border-t-4 ${status.borderColor} transition-all duration-300 ${
                status.featured 
                  ? "lg:scale-105 shadow-[0_0_30px_hsl(var(--signal-prime)/0.2)]" 
                  : ""
              }`}
            >
              <div className={`${status.textColor} font-mono text-5xl font-bold mb-3`}>
                {status.number}
              </div>
              <h3 className="text-xl font-bold text-foreground mb-3">{status.title}</h3>
              <div className={`${status.bgColor} text-background text-xs font-bold inline-block px-3 py-1 rounded mb-4`}>
                {status.badge}
              </div>
              <p className="text-sm text-muted-foreground">{status.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatusSection;
