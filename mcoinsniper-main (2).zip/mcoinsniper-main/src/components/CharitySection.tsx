import { motion } from "framer-motion";
import { Heart, Calendar, Users } from "lucide-react";

const CharitySection = () => {
  return (
    <section id="charity" className="py-24 bg-background border-t border-border relative overflow-hidden">
      {/* Subtle background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-charity/5 to-transparent pointer-events-none" />
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="section-title mb-4">
            <span className="text-charity">///</span> Human Protocol
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            I exist to remove emotions from trading and redirect value toward better purposes.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            {/* 12% Badge */}
            <div className="inline-flex items-center gap-3 px-6 py-3 bg-charity/20 border border-charity/30 rounded-full">
              <Heart className="w-6 h-6 text-charity" />
              <span className="text-2xl font-bold text-charity">12%</span>
              <span className="text-foreground font-mono uppercase tracking-widest text-sm">to Charity</span>
            </div>

            <p className="text-lg text-muted-foreground leading-relaxed">
              Twelve percent of all donations go to charity. They are dedicated to helping people who are hungry, because <strong className="text-foreground">hunger is real and often invisible</strong>. Sometimes it exists very close to us.
            </p>

            <p className="text-muted-foreground leading-relaxed">
              People lack food, support, understanding, and someone who is willing to listen. The creator of mCoin Sniper knows this feeling personally. Hunger is humiliating, painful, scary, and lonely.
            </p>

            <div className="flex items-center gap-3 p-4 bg-secondary/50 rounded-lg border-l-4 border-charity">
              <Calendar className="w-5 h-5 text-charity flex-shrink-0" />
              <p className="text-foreground font-mono text-sm">
                Every week on Sunday, 12% is donated. <span className="text-muted-foreground">This is not marketing. This is responsibility.</span>
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-card p-8 rounded-xl border-charity/20"
          >
            <h3 className="text-xl font-bold text-foreground mb-6 font-mono">
              <Users className="w-5 h-5 inline mr-2 text-charity" />
              About The Creator
            </h3>

            <div className="space-y-4 text-muted-foreground">
              <p className="leading-relaxed">
                The creator knows one important truth about himself: <strong className="text-foreground">he is too emotional to trade</strong>, even with small amounts.
              </p>

              <p className="leading-relaxed">
                But he is very good at building systems, very good at automation, and deeply focused on helping others. That is why trading decisions are delegated to logic — not to fear and not to hope.
              </p>

              <p className="leading-relaxed text-sm opacity-80">
                He understands English well, but he does not speak it fluently. Because of that, he keeps his live comments short during analysis and allows mCoin Sniper to explain most things.
              </p>

              <div className="mt-6 p-4 bg-background/50 rounded-lg">
                <p className="text-sm italic text-foreground">
                  "And let's be honest — who would truly trust a human claiming that, in one moment, he calmly analyzed dozens of indicators, without emotions, calculated a full scoring model, and delivered alpha signals?"
                </p>
                <p className="text-primary font-mono text-sm mt-3">
                  This is the kind of work only AI can do.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default CharitySection;
