import { motion } from "framer-motion";
import telegramImage from "@/assets/telegram-signals.png";
const SignalsSection = () => {
  return <section id="signals" className="py-24 bg-secondary/10 border-t border-border">
      <div className="container mx-auto px-6 max-w-5xl">
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} className="text-center mb-6">
          <h2 className="section-title mb-4">
            /// Signal Feeds
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            I provide four types of signals. Viewers can submit their own tokens for analysis. 
            I apply the same rules every time. There are no favorites and no bias. <strong className="text-foreground">
Only data matters.</strong>
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 items-stretch mt-12">
          {/* Free Channel */}
          <motion.div initial={{
          opacity: 0,
          x: -30
        }} whileInView={{
          opacity: 1,
          x: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="bg-secondary/50 border border-border p-8 rounded-xl flex flex-col justify-between">
            <div>
              <h3 className="text-2xl font-bold text-muted-foreground mb-2">Free Signals</h3>
              <p className="text-muted-foreground/60 text-sm mb-4">Capital protection layer — designed to protect viewers from bad trades and unnecessary losses.</p>
              <div className="space-y-4">
                <a href="https://t.me/mcoinsniper" target="_blank" rel="noopener noreferrer" className="block">
                  <div className="flex items-center p-4 bg-background/50 rounded-lg border-l-4 border-signal-skip hover:bg-background transition-colors">
                    <span className="font-mono text-signal-skip font-bold mr-4 w-16">SKIP</span>
                    <span className="text-sm text-muted-foreground">Bad trades filtered out. Risk too high.</span>
                  </div>
                </a>
                <a href="https://t.me/mcoinsniper" target="_blank" rel="noopener noreferrer" className="block">
                  <div className="flex items-center p-4 bg-background/50 rounded-lg border-l-4 border-signal-risky hover:bg-background transition-colors">
                    <span className="font-mono text-signal-risky font-bold mr-4 w-16">RISKY</span>
                    <span className="text-sm text-muted-foreground">High volatility alerts. Wait for clarity.</span>
                  </div>
                </a>
              </div>
            </div>
            
            <a href="https://t.me/mcoinsniper" target="_blank" rel="noopener noreferrer" className="mt-8 w-full py-4 border border-border hover:border-primary hover:text-primary font-bold rounded text-center transition-all duration-300 uppercase tracking-widest text-sm block">
              Join Free Channel
            </a>
          </motion.div>

          {/* Premium Channel */}
          <motion.div initial={{
          opacity: 0,
          x: 30
        }} whileInView={{
          opacity: 1,
          x: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: 0.2
        }} className="glass-card border-primary/30 p-8 rounded-xl relative overflow-hidden flex flex-col justify-between">
            <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-xs font-bold px-4 py-1.5 rounded-bl-lg">
              ALPHA
            </div>
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-2">Private Group</h3>
              <p className="text-muted-foreground text-sm mb-4">Advanced signals that support the continued development of mCoin Sniper and its mission.</p>
              <div className="space-y-4">
                <div className="flex items-center p-4 bg-background/30 rounded-lg border-l-4 border-signal-watch">
                  <span className="font-mono text-signal-watch font-bold mr-4 w-16">WATCH</span>
                  <span className="text-sm text-secondary-foreground">Setups developing live. Observation mode.</span>
                </div>
                <div className="flex items-center p-4 bg-background/30 rounded-lg border-l-4 border-signal-prime">
                  <span className="font-mono text-signal-prime font-bold mr-4 w-16">PRIME</span>
                  <span className="text-sm text-secondary-foreground">High-confidence conditions met. All aligned.</span>
                </div>
              </div>
            </div>
            <a href="https://t.me/mcoinsnipers" target="_blank" rel="noopener noreferrer" className="mt-8 w-full py-4 bg-primary hover:brightness-110 text-primary-foreground font-bold rounded text-center transition-all duration-300 uppercase tracking-widest text-sm block">
              Join The Private Group
            </a>
          </motion.div>
        </div>

        {/* Telegram Image */}
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        delay: 0.3
      }} className="mt-16 text-center">
          <img alt="Telegram Signals" className="max-w-2xl mx-auto w-full rounded-xl shadow-2xl shadow-primary/10" src="/lovable-uploads/d28165ee-7dd4-4a65-95af-5777e0e17472.png" />
          <p className="text-muted-foreground text-sm mt-4 font-mono">
            Watch and Prime signals are advanced — shared in private Telegram group
          </p>
        </motion.div>
      </div>
    </section>;
};
export default SignalsSection;