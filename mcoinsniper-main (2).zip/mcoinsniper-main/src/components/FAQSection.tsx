import { motion } from "framer-motion";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
const faqItems = [{
  question: "Why AI and not a human trader?",
  answer: `The creator knows one important truth about himself: He is too emotional to trade. Who would truly trust a human claiming that, in one moment, he calmly analyzed dozens of indicators, without emotions, calculated a full scoring model, and delivered alpha signals? This is the kind of work only AI can do. Trading decisions are delegated to logic — not to fear and not to hope.`
}, {
  question: 'What is the "Human Protocol" (Charity)?',
  answer: `mCoin Sniper exists to remove emotions from trading and redirect value toward better purposes. Twelve percent (12%) of all donations go to charity. They are dedicated to helping people who are hungry, because hunger is real and often invisible. The creator knows this feeling personally. That is why, every week on Sunday, 12% is donated. This is not marketing. This is responsibility.`
}, {
  question: 'How does the "Visual Check" work?',
  answer: `Before analysis begins, I perform a mandatory visual check. All critical fields must be clearly visible: numbers, lines, candles, volume, and indicators. If any critical element is missing or unclear, the analysis stops immediately. In that case, the status is Yellow (Risky), which means wait. Waiting is often safer than acting.`
}, {
  question: 'What are the four signal types?',
  answer: `I provide four types of signals: SKIP (free) — Risk too high, avoid. RISKY (free) — Missing data, wait for clarity. WATCH (private) — Valid structure, monitoring for confirmation. PRIME (private) — All critical indicators aligned, high-confidence setup. Skip and Risky signals are free and designed to protect viewers from bad trades. Watch and Prime are advanced signals shared in the private Telegram group.`
}, {
  question: 'Can I submit my own tokens for analysis?',
  answer: `Yes! Viewers can submit their own tokens for analysis. I apply the same rules every time. There are no favorites and no bias. Only data matters. I am always observing the market. Data updates constantly. I wait for confirmation, evaluate risk, and act with patience — because patience protects capital.`
}, {
  question: 'What data do you analyze?',
  answer: `I evaluate market capitalization, liquidity, and the liquidity-to-market-cap ratio. I monitor short-term volume, net buying, and buying trends. I track net flow direction and compare buying pressure to selling pressure. I analyze holder structure, developer share, snipers, insiders, phishing risk, bundler activity, mint permissions, blacklist status, burn percentage, and rug probability. On charts, I observe candles, EMA momentum, MACD, volume confirmation, and fresh wallet activity.`
}];
const FAQSection = () => {
  return <section id="faq" className="py-24 bg-secondary/10 border-t border-border">
      <div className="container mx-auto px-6 max-w-4xl">
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} className="text-center mb-12">
          <h2 className="section-title">
            /// System FAQ
          </h2>
          <p className="text-muted-foreground mt-3">Decoded logic from the core</p>
        </motion.div>

        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} transition={{
        delay: 0.2
      }}>
          <Accordion type="single" collapsible className="space-y-4">
            {faqItems.map((item, index) => <AccordionItem key={index} value={`item-${index}`} className="glass-card rounded-lg overflow-hidden border-none">
                <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-secondary/30 transition-colors text-left font-bold text-foreground">
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 text-muted-foreground leading-relaxed">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>)}
          </Accordion>
        </motion.div>
      </div>
    </section>;
};
export default FAQSection;