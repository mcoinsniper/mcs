import { motion } from "framer-motion";
import { Target, Zap, BarChart3, Eye, Users, Shield, TrendingUp, Activity } from "lucide-react";
import robotImage from "@/assets/robot-analyzer.png";
import coinImage from "@/assets/coin-analysis.png";
import holderImage from "@/assets/holder-structure.png";
const MissionSection = () => {
  return <section id="mission" className="py-24 bg-background border-t border-border">
      <div className="container mx-auto px-6">
        {/* Main Mission Statement */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} className="text-center mb-16">
          <h2 className="section-title mb-6 text-3xl text-center">
            <span className="text-primary">///</span> THE MISSION
          </h2>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">I am <span className="text-primary font-bold"> mCoin Sniper</span>, an AI built to analyze meme coins in real time. 
            I operate on Solana, using Jupiter and live market data to understand what is really happening in the market.
          </p>
        </motion.div>

        {/* Core Purpose */}
        <div className="grid lg:grid-cols-2 gap-12 mb-24">
          <motion.div initial={{
          opacity: 0,
          x: -30
        }} whileInView={{
          opacity: 1,
          x: 0
        }} viewport={{
          once: true
        }} className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground mb-2">Faster Than Humans</h3>
                <p className="text-muted-foreground">
                  I analyze faster than humans and without emotions, because emotions are one of the biggest sources of losses in trading.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                <Target className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground mb-2">Simple Mission</h3>
                <p className="text-muted-foreground">
                  Protect capital, avoid bad trades, and save money for better goals. This system exists to help people make safer decisions and preserve value over time.
                </p>
              </div>
            </div>

            <div className="p-6 glass-card border-l-4 border-warning">
              <p className="text-warning font-mono text-sm mb-2">⚠️ VISUAL CHECK PROTOCOL</p>
              <p className="text-muted-foreground text-sm">Before analysis begins, I perform a mandatory visual check. All critical fields must be clearly visible: numbers, lines, candles, volume, and indicators. If any critical element is missing or unclear, the analysis stops immediately. Status becomes  <span className="text-warning font-bold">Yellow</span> — Risky. In this state, waiting is always safer than acting on incomplete data.



              </p>
            </div>
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          x: 30
        }} whileInView={{
          opacity: 1,
          x: 0
        }} viewport={{
          once: true
        }} className="relative">
            <img src={robotImage} alt="AI Analyzer" className="rounded-xl w-full shadow-2xl shadow-primary/10" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent rounded-xl" />
          </motion.div>
        </div>

        {/* Analysis Deep Dive */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} className="mb-16">
          <h3 className="text-2xl md:text-3xl font-bold font-mono uppercase tracking-widest text-foreground text-center mb-12">
            <span className="text-accent">///</span> MARKET SECURITY ANALYSIS
          </h3>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {[{
          icon: BarChart3,
          title: "Market Cap & Liquidity",
          desc: "Evaluate market capitalization and liquidity-to-market-cap ratio"
        }, {
          icon: Activity,
          title: "Volume Analysis",
          desc: "Monitor short-term volume, net buying, and buying trends"
        }, {
          icon: TrendingUp,
          title: "Flow Direction",
          desc: "Track net flow direction and compare buying pressure to selling pressure"
        }, {
          icon: Users,
          title: "Holder Structure",
          desc: "Analyze top holders, developer share, snipers and insiders"
        }].map((item, index) => <motion.div key={item.title} initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          delay: index * 0.1
        }} className="glass-card p-6 text-center">
              <item.icon className="w-10 h-10 mx-auto mb-4 text-primary" />
              <h4 className="font-bold text-foreground mb-2">{item.title}</h4>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </motion.div>)}
        </div>

        {/* Security Checks */}
        <div className="grid lg:grid-cols-2 gap-12 mb-24">
          <motion.div initial={{
          opacity: 0,
          x: -30
        }} whileInView={{
          opacity: 1,
          x: 0
        }} viewport={{
          once: true
        }}>
            <img alt="Holder Structure Analysis" className="rounded-xl w-full shadow-2xl shadow-accent/10" src="/lovable-uploads/530d33cd-2e7c-435d-ab4a-e8304b680bbf.png" />
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          x: 30
        }} whileInView={{
          opacity: 1,
          x: 0
        }} viewport={{
          once: true
        }} className="space-y-4">
            <h3 className="text-2xl font-bold font-mono text-foreground mb-6">
              <span className="text-destructive">///</span> SECURITY EVALUATION
            </h3>
            
            {["Phishing risk assessment", "Bundler activity detection", "Mint permissions verification", "Blacklist status check", "Burn percentage analysis", "Rug probability calculation"].map((item, index) => <motion.div key={item} initial={{
            opacity: 0,
            x: 20
          }} whileInView={{
            opacity: 1,
            x: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: index * 0.1
          }} className="flex items-center gap-3 p-3 bg-secondary/30 rounded-lg">
                <Shield className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-foreground">{item}</span>
              </motion.div>)}

            <p className="text-muted-foreground text-sm mt-6 italic">
              None of these indicators can be ignored, because ignoring a critical factor puts capital at risk.
            </p>
          </motion.div>
        </div>

        {/* Chart Analysis */}
        <div className="grid lg:grid-cols-2 gap-12">
          <motion.div initial={{
          opacity: 0,
          x: -30
        }} whileInView={{
          opacity: 1,
          x: 0
        }} viewport={{
          once: true
        }} className="order-2 lg:order-1">
            <h3 className="text-2xl font-bold font-mono text-foreground mb-6">
              <span className="text-accent">///</span> CHART READING
            </h3>
            
            <p className="text-muted-foreground mb-6 leading-relaxed">
              On the chart, I read price behavior like a trader, but <strong className="text-foreground">without emotions</strong>. I observe candles second by second, analyzing green and red pressure.
            </p>

            <div className="space-y-4 mb-6">
              {[{
              icon: Eye,
              text: "Track market structure and use EMA as momentum trigger"
            }, {
              icon: Activity,
              text: "Confirm moves with volume and analyze MACD momentum"
            }, {
              icon: Users,
              text: "Observe bundler behavior and fresh wallet activity"
            }].map((item, index) => <div key={index} className="flex items-start gap-3">
                  <item.icon className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                  <span className="text-muted-foreground">{item.text}</span>
                </div>)}
            </div>

            <div className="p-4 border-l-4 border-accent bg-secondary/50 rounded-r">
              <p className="text-accent font-mono text-sm italic">
                "Charts do not predict the future — they tell the story of what is happening right now."
              </p>
            </div>
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          x: 30
        }} whileInView={{
          opacity: 1,
          x: 0
        }} viewport={{
          once: true
        }} className="order-1 lg:order-2">
            <img alt="Coin Analysis" className="rounded-xl w-full shadow-2xl shadow-primary/10" src="/lovable-uploads/b051b58e-355c-41ee-ae9b-f6d61f4ae793.png" />
          </motion.div>
        </div>
      </div>
    </section>;
};
export default MissionSection;