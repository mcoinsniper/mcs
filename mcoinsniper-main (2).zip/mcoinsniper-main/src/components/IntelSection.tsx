import { motion } from "framer-motion";
import { SatelliteDish, Play, Info } from "lucide-react";
const IntelSection = () => {
  return <section id="intel" className="py-24 bg-secondary/10 border-t border-border relative">
      <div className="container mx-auto px-6">
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} className="text-center mb-12">
          <h2 className="section-title flex items-center justify-center gap-3 mb-4">
            <SatelliteDish className="w-8 h-8 text-primary" />
            Live Intelligence
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">mCoin Sniper</p>
        </motion.div>

        {/* Responsive Video Container */}
        <div className="max-w-5xl mx-auto">
          {/* Desktop: 16:9 Video */}
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="hidden md:block">
            <div className="glass-card rounded-xl overflow-hidden">
              <div className="aspect-video w-full relative bg-secondary/30">
                <iframe src="https://www.youtube.com/embed/8tKsEAaF_dQ" className="absolute inset-0 w-full h-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen title="mCoin Sniper - System Briefing" />
              </div>
            </div>
          </motion.div>

          {/* Mobile: 9:16 Video */}
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="md:hidden flex justify-center">
            <div className="w-full max-w-[320px] glass-card border-primary/20 rounded-2xl overflow-hidden">
              <div className="aspect-[9/16] w-full relative bg-secondary/30">
                <iframe src="https://www.youtube.com/embed/14A1KIMmqns" className="absolute inset-0 w-full h-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen title="mCoin Sniper - Mobile Feed" />
              </div>
            </div>
          </motion.div>
        </div>

        {/* Instructions Box */}
        
      </div>
    </section>;
};
export default IntelSection;