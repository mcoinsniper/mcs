import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import logo from "@/assets/logo-mcoin-sniper.jpeg";
const navLinks = [{
  href: "#about",
  label: "ABOUT"
}, {
  href: "#mission",
  label: "MISSION"
}, {
  href: "#intel",
  label: "INTEL"
}, {
  href: "#status",
  label: "STATUS"
}, {
  href: "#signals",
  label: "SIGNALS"
}, {
  href: "#charity",
  label: "CHARITY"
}, {
  href: "#faq",
  label: "FAQ"
}];
const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  return <motion.nav initial={{
    y: -100
  }} animate={{
    y: 0
  }} transition={{
    duration: 0.5
  }} className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? "glass-card border-b border-border" : "bg-transparent"}`}>
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <a href="#" className="flex items-center gap-3 group">
          <img alt="mCoin Sniper Logo" className="w-10 h-10 rounded-full object-cover ring-2 ring-primary/50 group-hover:ring-primary transition-all" src="/lovable-uploads/64b22fb6-e268-44b4-84f3-e1088e3f4494.png" />
          <span className="text-xl md:text-2xl font-bold font-mono tracking-tighter text-foreground">
            mCoin<span className="text-primary">Sniper</span>
          </span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden lg:flex space-x-6 text-sm font-semibold tracking-wide items-center font-mono text-muted-foreground">
          {navLinks.map(link => <a key={link.href} href={link.href} className="hover:text-primary transition-colors duration-200 relative group">
              {link.label}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full" />
            </a>)}
        </div>

        <div className="flex items-center gap-4">
          {/* YouTube Link */}
          <a href="https://www.youtube.com/@mCoinSniper" target="_blank" rel="noopener noreferrer" className="hidden md:flex text-muted-foreground hover:text-destructive transition-colors">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
            </svg>
          </a>

          <a href="https://t.me/mcoinsniper" target="_blank" rel="noopener noreferrer" className="bg-primary text-primary-foreground px-4 md:px-5 py-2 md:py-2.5 rounded font-bold hover:brightness-110 transition-all duration-200 transform hover:scale-105 uppercase text-xs tracking-wider flex items-center gap-2">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
            </svg>
            <span className="hidden sm:inline">Join</span>
          </a>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden text-foreground">
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && <motion.div initial={{
      opacity: 0,
      y: -20
    }} animate={{
      opacity: 1,
      y: 0
    }} className="lg:hidden glass-card border-t border-border">
          <div className="container mx-auto px-6 py-4 flex flex-col space-y-4">
            {navLinks.map(link => <a key={link.href} href={link.href} onClick={() => setIsMobileMenuOpen(false)} className="text-muted-foreground hover:text-primary transition-colors font-mono text-sm">
                {link.label}
              </a>)}
          </div>
        </motion.div>}
    </motion.nav>;
};
export default Navbar;