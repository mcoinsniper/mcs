import { motion } from "framer-motion";
import { Binoculars, Brain, Shield, Skull } from "lucide-react";
const features = [{
  icon: Binoculars,
  title: "Reconnaissance",
  description: "Full battlefield scan before engagement.",
  color: "text-accent"
}, {
  icon: Brain,
  title: "Logic Core",
  description: "Buying pressure vs Selling pressure. Pure math.",
  color: "text-primary"
}, {
  icon: Shield,
  title: "Visual Check",
  description: "If numbers or candles are missing, I wait.",
  color: "text-warning"
}, {
  icon: Skull,
  title: "Survival",
  description: "Capital protection is the highest priority.",
  color: "text-destructive"
}];
const AboutSection = () => {
  return <section id="about" className="py-24 bg-secondary/20 border-y border-border relative">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div initial={{
          opacity: 0,
          x: -50
        }} whileInView={{
          opacity: 1,
          x: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }}>
            <h2 className="text-3xl md:text-4xl font-bold font-mono uppercase tracking-widest text-foreground mb-6">
              <span className="text-destructive">///</span> OPERATIONAL MODE: WAR
            </h2>
            <p className="text-muted-foreground mb-6 leading-relaxed text-lg">I operate in what I call <strong className="text-foreground">War Mode</strong>. Before any action is taken, I perform full reconnaissance. I scan the entire battlefield before I even consider a target.
            
            
            </p>
            <p className="text-muted-foreground mb-8 leading-relaxed">I need to understand who the token is, what it did in the past, and how it behaves now. There are no rushed decisions, no ignored signals, and no shortcuts.   <strong className="text-foreground">
 
Missing data always means danger!</strong>
            </p>
            <div className="p-4 border-l-4 border-primary bg-secondary/50 rounded-r">
              <p className="text-primary font-mono text-sm italic">
                "Charts do not predict the future — they tell the story of what is happening right now."
              </p>
            </div>
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          x: 50
        }} whileInView={{
          opacity: 1,
          x: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: 0.2
        }} className="grid grid-cols-2 gap-4">
            {features.map((feature, index) => <motion.div key={feature.title} initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.4,
            delay: 0.1 * index
          }} whileHover={{
            y: -5,
            scale: 1.02
          }} className="glass-card p-6 rounded-lg text-center group cursor-default">
                <feature.icon className={`w-10 h-10 mx-auto mb-3 ${feature.color} group-hover:scale-110 transition-transform duration-300`} />
                <h4 className="font-bold text-foreground mb-2">{feature.title}</h4>
                <p className="text-xs text-muted-foreground">{feature.description}</p>
              </motion.div>)}
          </motion.div>
        </div>
      </div>
    </section>;
};
export default AboutSection;