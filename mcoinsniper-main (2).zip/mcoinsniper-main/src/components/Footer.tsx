import { motion } from "framer-motion";
import { Rocket, AlertTriangle } from "lucide-react";
import logo from "@/assets/logo-mcoin-sniper.jpeg";
const socialLinks = [{
  name: "Telegram",
  href: "https://t.me/mcoinsniper",
  icon: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
      </svg>,
  hoverColor: "hover:bg-accent hover:border-accent"
}, {
  name: "YouTube",
  href: "https://www.youtube.com/@mCoinSniper",
  icon: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
      </svg>,
  hoverColor: "hover:bg-destructive hover:border-destructive"
}, {
  name: "X.com",
  href: "https://x.com/mcoinsnipers",
  icon: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
      </svg>,
  hoverColor: "hover:bg-foreground hover:border-foreground group-hover:text-background"
}, {
  name: "TikTok",
  href: "https://tiktok.com/@mcoinsnipers",
  icon: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
      </svg>,
  hoverColor: "hover:bg-pink-500 hover:border-pink-500"
}, {
  name: "Kick",
  href: "https://kick.com/mcoinsnipers",
  icon: <span className="text-lg font-black italic">K</span>,
  hoverColor: "hover:bg-[#53FC18] hover:border-[#53FC18] group-hover:text-background"
}];
const Footer = () => {
  return <footer className="bg-background py-16 border-t border-border relative overflow-hidden">
      {/* Launch Date Badge */}
      <motion.div initial={{
      opacity: 0,
      y: -20
    }} whileInView={{
      opacity: 1,
      y: 0
    }} viewport={{
      once: true
    }} className="absolute top-6 left-1/2 -translate-x-1/2">
        <div className="inline-flex items-center gap-2 px-4 py-2 border border-primary/30 rounded-full bg-secondary/50 text-primary text-xs font-mono uppercase tracking-widest">
          <Rocket className="w-4 h-4" />
          Official Launch: 01.01.2026
        </div>
      </motion.div>

      <div className="container mx-auto px-6 relative z-10 pt-12">
        <div className="flex flex-col items-center mb-10">
          {/* Logo */}
          <motion.a href="#" initial={{
          opacity: 0
        }} whileInView={{
          opacity: 1
        }} viewport={{
          once: true
        }} whileHover={{
          scale: 1.05
        }} className="flex items-center gap-3 text-3xl md:text-4xl font-bold font-mono tracking-tighter text-foreground mb-8">
            <img alt="mCoin Sniper" className="w-12 h-12 rounded-full ring-2 ring-primary/50" src="/lovable-uploads/ad1f98e8-18e4-471c-9a0c-7114c08f15b4.png" />
            <span>Sniper<span className="text-primary">Sniper</span></span>
          </motion.a>

          {/* Disclaimer */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} className="max-w-2xl text-center mb-8 p-5 border border-border rounded-lg bg-secondary/30">
            <p className="text-warning text-xs font-mono uppercase tracking-wide mb-3 flex items-center justify-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Disclaimer
            </p>
            <p className="text-muted-foreground text-sm leading-relaxed">The content provided by mCoin Sniper is for informational and educational purposes only.
This is not financial advice.
Cryptocurrency trading involves a high level of risk, and you should strictly perform your own research before making any investment decisions.<strong className="text-foreground">
This is not financial advice.</strong> Cryptocurrency trading involves a high level of risk, and you should strictly perform your own research before making any investment decisions.
            </p>
          </motion.div>

          {/* Telegram CTA */}
          <motion.a href="https://t.me/mcoinsniper" target="_blank" rel="noopener noreferrer" initial={{
          opacity: 0
        }} whileInView={{
          opacity: 1
        }} viewport={{
          once: true
        }} whileHover={{
          scale: 1.05
        }} className="flex items-center gap-2 text-accent hover:text-foreground transition-colors mb-10 font-bold text-sm uppercase tracking-widest">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
            </svg>
            Join Official Telegram
          </motion.a>
        </div>

        {/* Social Media Grid */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} className="grid grid-cols-5 gap-4 max-w-md mx-auto mb-12">
          {socialLinks.map(social => <a key={social.name} href={social.href} target="_blank" rel="noopener noreferrer" className="group flex flex-col items-center">
              <div className={`w-12 h-12 bg-secondary rounded-full flex items-center justify-center border border-border text-muted-foreground group-hover:text-foreground transition-all duration-300 ${social.hoverColor}`}>
                {social.icon}
              </div>
              <span className="text-xs text-muted-foreground mt-2 group-hover:text-foreground transition-colors">
                {social.name}
              </span>
            </a>)}
        </motion.div>

        <div className="text-center text-xs text-muted-foreground/50 font-mono">
          &copy; 2026 mCoin Sniper. Logic Over Emotion.
        </div>
      </div>
    </footer>;
};
export default Footer;