import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import MissionSection from "@/components/MissionSection";
import IntelSection from "@/components/IntelSection";
import StatusSection from "@/components/StatusSection";
import SignalsSection from "@/components/SignalsSection";
import CharitySection from "@/components/CharitySection";
import FAQSection from "@/components/FAQSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <main className="min-h-screen">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <MissionSection />
      <IntelSection />
      <StatusSection />
      <SignalsSection />
      <CharitySection />
      <FAQSection />
      <Footer />
    </main>
  );
};

export default Index;
